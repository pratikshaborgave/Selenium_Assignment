package Task;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Selenium_Task {

	public static void main(String[] args) throws InterruptedException {
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\pborgave\\eclipse\\Selenium_Assesment_\\Soft\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 System.out.println("Chrome started sucessfully.....");
		 Thread.sleep(3000);
		 
		 //Opening link
		 driver.get("http://automationpractice.com/index.php");
		 System.out.println("Link Opened suessfully.....");
		 Thread.sleep(3000);
		
		  
		  
		 
		  driver.manage().window().maximize();
		 

		  //Click on Sign in
		  driver.findElement(By.linkText("Sign in")).click();
		  Thread.sleep(3000);
		  
		  //Passing the login credentials
		  driver.findElement(By.id("email")).sendKeys("pratikshaborgave1234@gmail.com");
		  Thread.sleep(3000);
		  driver.findElement(By.id("passwd")).sendKeys("pratiksha1234");
		  Thread.sleep(3000);
		  driver.findElement(By.id("SubmitLogin")).click();
		  Thread.sleep(3000);
		  System.out.println("Login sucessfully.....");
		  
		  
		  //Initialize Actions class object
		  Actions actions=new Actions(driver);
		  //Moving the  cursor over Women's link.
		  WebElement womenTab=driver.findElement(By.linkText("WOMEN"));
		  //Clicking  on the sub menu 'T-shirts'.
		  WebElement TshirtTab=driver.findElement(By.xpath("//div[@id='block_top_menu']/ul/li[1]/ul/li[1]/ul//a[@title='T-shirts']"));
		  actions.moveToElement(womenTab).moveToElement(TshirtTab).click().perform();
		  Thread.sleep(3000);

		  
		  //Mouse over the product displaying
		  WebElement Img=driver.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[1]/div/a[1]/img"));
		  
		  //Clicking on the more button
		  WebElement MoreBtn=driver.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[2]/div[2]/a[2]/span"));
		  Actions actions1=new Actions(driver);
		  actions1.moveToElement(Img).moveToElement(MoreBtn).click().perform();

		  //Changing the product quantity by 2
		  driver.findElement(By.id("quantity_wanted")).clear();
		  driver.findElement(By.id("quantity_wanted")).sendKeys("2");
		  System.out.println("product quantity changed as 2.....");

		  //Selecting the size of product as L
		  WebElement Sizedrpdwn=driver.findElement(By.xpath("//*[@id='group_1']"));
		  Select oSelect=new Select(Sizedrpdwn);
		  oSelect.selectByVisibleText("L");
		  System.out.println("Size Selected.....");

		  //Selecting Color
		  driver.findElement(By.id("color_11")).click();
		  System.out.println("Color selected.....");

		  //Clicking on add to cart   
		  driver.findElement(By.xpath("//p[@id='add_to_cart']//span[.='Add to cart']")).click();
		  System.out.println("Product added to cart.....");

		  //Clicking on proceed
		  driver.findElement(By.xpath("/html//div[@id='layer_cart']//a[@title='Proceed to checkout']/span")).click();
		  System.out.println("Proceed.....");
		  
	}

}
